package com.cg.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class QueryDemo {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");

		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();

		String qry = "select emp from Employee emp where emp.empsal>=300 and emp.empsal<=500 ";
		Query query = manager.createQuery(qry);
		List list = query.getResultList();

		for (Object object : list) {

			System.out.println(object);

		}

		manager.getTransaction().commit();

		manager.close();
		factory.close();

	}

}
