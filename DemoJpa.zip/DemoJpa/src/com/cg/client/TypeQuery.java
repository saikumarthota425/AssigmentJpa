package com.cg.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entity.Employee;

public class TypeQuery {
	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");

		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();

		String qry = "select emp from Employee emp where emp.empsal>=300 and emp.empsal<=500 ";
		TypedQuery<Employee> query = manager.createQuery(qry, Employee.class);
		List<Employee> list = query.getResultList();
		for (Object obj : list) {
			System.out.println(obj);

		}

		manager.getTransaction().commit();

		manager.close();
		factory.close();

	}
}
